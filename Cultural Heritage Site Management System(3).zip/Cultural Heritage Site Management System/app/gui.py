import sys
import os
from pathlib import Path

# 添加项目根目录到 sys.path
current_file = Path(__file__).resolve()
project_root = current_file.parent.parent
sys.path.insert(0, str(project_root))

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QGridLayout,
    QPushButton, QLabel, QInputDialog, QMessageBox, QTableWidget, 
    QTableWidgetItem, QTabWidget, QHeaderView, QComboBox, QLineEdit
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor

# 导入核心模块
from core.manager import CulturalHeritageSiteManager
from core.artifact import Artifact, Significance, ArtifactType
from core.visitors import VisitorGroup


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.manager = CulturalHeritageSiteManager()
        self.manager.load_artifacts()
        self.manager.load_visitors()

        self.setup_ui()
        self.apply_styles()
        
    def setup_ui(self):
        """设置主界面UI"""
        self.setWindowTitle("Cultural Heritage Management System")
        self.setGeometry(100, 100, 1000, 600)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)
        
        # 顶部按钮区域
        btn_layout = QGridLayout()
        main_layout.addLayout(btn_layout)

        # 创建按钮
        buttons = [
            ("Add Artifact", self.add_artifact, 0, 0),
            ("Add Visitor Group", self.add_visitor_group, 0, 1),
            ("Show Artifacts", self.show_artifacts, 1, 0),
            ("Show Visitors", self.show_visitors, 1, 1),
            ("Save to CSV", self.save_to_csv, 2, 0),
            ("Search Artifacts", self.search_artifacts, 2, 1),
            ("Import from CSV", self.import_from_csv, 3, 0)
        ]
        
        for text, handler, row, col in buttons:
            btn = QPushButton(text)
            btn.clicked.connect(handler)
            btn_layout.addWidget(btn, row, col)
        
        # 搜索框
        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search artifacts by era...")
        self.search_box.returnPressed.connect(self.search_artifacts)
        btn_layout.addWidget(self.search_box, 3, 1)
        
        # 状态标签
        self.status_label = QLabel("System Ready")
        main_layout.addWidget(self.status_label)

        # 创建标签页
        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)
        
        # 初始化表格
        self.setup_tables()
    
    def setup_tables(self):
        """初始化表格"""
        # 文物表格
        self.artifact_table = QTableWidget()
        self.artifact_table.setColumnCount(5)
        self.artifact_table.setHorizontalHeaderLabels(["ID", "Name", "Era", "Significance", "Type"])
        self.artifact_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.artifact_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.artifact_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.tab_widget.addTab(self.artifact_table, "Artifacts")
        
        # 访客表格
        self.visitor_table = QTableWidget()
        self.visitor_table.setColumnCount(3)
        self.visitor_table.setHorizontalHeaderLabels(["ID", "Arrival Time", "Priority"])
        self.visitor_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.visitor_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.visitor_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.tab_widget.addTab(self.visitor_table, "Visitors")
        
        # 初始加载数据
        self.update_artifact_table()
        self.update_visitor_table()
    
    def apply_styles(self):
        """应用样式表"""
        self.setStyleSheet("""
            QMainWindow { background-color: #f5f5f5; }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px 15px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover { background-color: #45a049; }
            QPushButton:pressed { background-color: #3d8b40; }
            QTableWidget { gridline-color: #ddd; }
            QHeaderView::section {
                background-color: #e0e0e0;
                padding: 5px;
                border: 1px solid #ccc;
                font-weight: bold;
            }
            QTabWidget::pane { border: 1px solid #ccc; border-radius: 4px; padding: 5px; }
            QTabBar::tab {
                background: #f0f0f0;
                border: 1px solid #ccc;
                border-bottom: none;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                padding: 5px 10px;
            }
            QTabBar::tab:selected { background: white; color: #4CAF50; font-weight: bold; }
            QLabel { font-size: 14px; padding: 5px; }
        """)
    
    def update_artifact_table(self):
        """更新文物表格"""
        self.artifact_table.setRowCount(len(self.manager.artifacts))
        for row, artifact in enumerate(self.manager.artifacts):
            items = [
                str(artifact.artifact_id),
                artifact.name,
                artifact.era,
                artifact.significance.name,
                artifact.artifact_type.name
            ]
            
            for col, text in enumerate(items):
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                
                # 根据重要性设置颜色
                if artifact.significance == Significance.HIGH:
                    item.setBackground(QColor(255, 230, 230))
                elif artifact.significance == Significance.MEDIUM:
                    item.setBackground(QColor(255, 255, 230))
                
                self.artifact_table.setItem(row, col, item)
    
    def update_visitor_table(self):
        """更新访客表格"""
        self.visitor_table.setRowCount(len(self.manager.visitor_queue))
        for row, visitor in enumerate(self.manager.visitor_queue):
            items = [
                str(visitor.group_id),
                str(visitor.arrival_time),
                visitor.reservation_priority.name
            ]
            
            for col, text in enumerate(items):
                item = QTableWidgetItem(text)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                
                # 根据优先级设置颜色
                if visitor.reservation_priority == "HIGH":
                    item.setBackground(QColor(255, 230, 230))
                elif visitor.reservation_priority == "MEDIUM":
                    item.setBackground(QColor(255, 255, 230))
                
                self.visitor_table.setItem(row, col, item)
    
    def add_artifact(self):
        """添加文物对话框"""
        try:
            inputs = self.get_artifact_inputs()
            if not all(inputs.values()):
                return
                
            new_artifact = Artifact(
                inputs["id"],
                inputs["name"],
                inputs["era"],
                Significance[inputs["significance"]],
                ArtifactType[inputs["type"]]
            )
            
            self.manager.add_artifact(new_artifact)
            self.status_label.setText(f"Added: {new_artifact.name}")
            self.update_artifact_table()
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"添加失败: {str(e)}")
    
    def get_artifact_inputs(self):
        """获取文物输入数据"""
        inputs = {}
        
        id, ok = QInputDialog.getInt(self, "Add Artifact", "Artifact ID:")
        if not ok: return {}
        inputs["id"] = id
        
        name, ok = QInputDialog.getText(self, "Add Artifact", "Name:")
        if not ok: return {}
        inputs["name"] = name
        
        era, ok = QInputDialog.getText(self, "Add Artifact", "Era:")
        if not ok: return {}
        inputs["era"] = era
        
        significance, ok = QInputDialog.getItem(
            self, "Add Artifact", "Significance:", 
            [s.name for s in Significance], 0, False
        )
        if not ok: return {}
        inputs["significance"] = significance
        
        artifact_type, ok = QInputDialog.getItem(
            self, "Add Artifact", "Type:", 
            [t.name for t in ArtifactType], 0, False
        )
        if not ok: return {}
        inputs["type"] = artifact_type
        
        return inputs
    
    def add_visitor_group(self):
        """添加访客组"""
        try:
            inputs = self.get_visitor_inputs()
            if not all(inputs.values()):
                return
                
            new_visitor = VisitorGroup(
                inputs["id"],
                inputs["time"],
                inputs["priority"],
                inputs["preference"]
            )
            
            self.manager.add_visitor_group(new_visitor)
            self.status_label.setText(f"Added: Group {new_visitor.group_id}")
            self.update_visitor_table()
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"添加失败: {str(e)}")
    
    def get_visitor_inputs(self):
        """获取访客输入数据"""
        inputs = {}
        
        id, ok = QInputDialog.getInt(self, "Add Visitor", "Group ID:")
        if not ok: return {}
        inputs["id"] = id
        
        time, ok = QInputDialog.getText(self, "Add Visitor", "Arrival Time:")
        if not ok: return {}
        inputs["time"] = time
        
        priority, ok = QInputDialog.getItem(
            self, "Add Visitor", "Priority:", 
            ["HIGH", "MEDIUM", "LOW"], 1, False
        )
        if not ok: return {}
        inputs["priority"] = priority
        
        preference, ok = QInputDialog.getText(self, "Add Visitor", "Preference (Optional):")
        inputs["preference"] = preference if ok and preference else None
        
        return inputs
    
    def show_artifacts(self):
        """显示所有文物"""
        self.update_artifact_table()
        self.tab_widget.setCurrentIndex(0)
    
    def show_visitors(self):
        """显示所有访客"""
        self.update_visitor_table()
        self.tab_widget.setCurrentIndex(1)
    
    def save_to_csv(self):
        """保存数据"""
        try:
            self.manager.save_to_csv()
            self.status_label.setText("Data saved successfully")
            QMessageBox.information(self, "Success", "Data saved to CSV files")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"保存失败: {str(e)}")
    
    def search_artifacts(self):
        """搜索文物"""
        era = self.search_box.text().strip()
        if not era:
            QMessageBox.warning(self, "Search", "Please enter an era")
            return
            
        results = self.manager.search_artifacts_by_era(era)
        if not results:
            QMessageBox.information(self, "Search", f"No artifacts found for era: {era}")
            return
            
        self.artifact_table.setRowCount(len(results))
        for row, artifact in enumerate(results):
            for col, text in enumerate([
                str(artifact.artifact_id),
                artifact.name,
                artifact.era,
                artifact.significance.name,
                artifact.artifact_type.name
            ]):
                self.artifact_table.setItem(row, col, QTableWidgetItem(text))
        
        self.tab_widget.setCurrentIndex(0)
        self.status_label.setText(f"Found {len(results)} artifacts for era: {era}")
    
    def import_from_csv(self):
        """从CSV导入数据"""
        try:
            self.manager.load_artifacts()
            self.manager.load_visitors()
            self.update_artifact_table()
            self.update_visitor_table()
            self.status_label.setText(
                f"Imported: {len(self.manager.artifacts)} artifacts, "
                f"{len(self.manager.visitor_queue)} visitors"
            )
        except Exception as e:
            QMessageBox.warning(self, "Error", f"导入失败: {str(e)}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # 设置高DPI支持
    app.setAttribute(Qt.AA_EnableHighDpiScaling)
    app.setAttribute(Qt.AA_UseHighDpiPixmaps)
    
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())