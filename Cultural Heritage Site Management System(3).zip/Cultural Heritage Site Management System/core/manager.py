import os
import pandas as pd
from datetime import datetime
from .artifact import Artifact, Significance, ArtifactType
from .visitors import VisitorGroup

class CulturalHeritageSiteManager:
    def __init__(self):
        self.artifacts = []
        self.visitor_queue = []
        # 计算项目根目录
        self.project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.file_dir = os.path.join(self.project_root, 'file')
        # 确保 file 目录存在
        if not os.path.exists(self.file_dir):
            print(f"警告: 文件目录不存在 - {self.file_dir}")

    def get_file_path(self, filename):
        """获取 file 目录下的文件路径"""
        return os.path.join(self.file_dir, filename)

    def load_artifacts(self, filename="cultural_heritage_artifacts.csv"):
        """从 file 目录加载文物数据，适配实际 CSV 列名"""
        filepath = self.get_file_path(filename)
        print(f"尝试加载文物文件: {filepath}")
        
        if not os.path.exists(filepath):
            print(f"错误: 文件不存在 - {filepath}")
            return
            
        try:
            data = pd.read_csv(filepath)
            print(f"成功读取 CSV 文件，共 {len(data)} 行数据")
            print(f"CSV 列名: {list(data.columns)}")  # 打印实际列名，用于调试
            self.artifacts.clear()
            
            # 列名映射字典（代码期望列名 -> 实际 CSV 可能的列名）
            column_mapping = {
                'artifact_id': ['artifact_id', 'artifact_ID'],  # 适配大小写差异
                'name': ['name'],
                'era': ['era'],
                'significance': ['significance', 'significanc'],  # 适配拼写差异
                'artifact_type': ['artifact_type', 'type']  # 适配列名差异
            }
            
            # 查找每个必需列在实际 CSV 中的对应列名
            csv_columns = {}
            for code_col, possible_cols in column_mapping.items():
                found = False
                for csv_col in possible_cols:
                    if csv_col in data.columns:
                        csv_columns[code_col] = csv_col
                        found = True
                        break
                if not found:
                    print(f"错误: 未找到列 '{code_col}' 的匹配项，可能的列名: {possible_cols}")
                    return
            
            print(f"列名映射: {csv_columns}")
            
            for idx, row in data.iterrows():
                try:
                    # 使用映射的列名获取数据
                    artifact_id = row[csv_columns['artifact_id']]
                    name = row[csv_columns['name']]
                    era = row[csv_columns['era']]
                    significance_str = str(row[csv_columns['significance']]).strip().upper()
                    artifact_type_str = str(row[csv_columns['artifact_type']]).strip().upper()
                    
                    # 验证并转换枚举值
                    if significance_str not in [s.name for s in Significance]:
                        raise ValueError(f"无效的 significance 值: {significance_str}，应为 {[s.name for s in Significance]}")
                    significance = Significance[significance_str]
                    
                    if artifact_type_str not in [t.name for t in ArtifactType]:
                        raise ValueError(f"无效的 artifact_type 值: {artifact_type_str}，应为 {[t.name for t in ArtifactType]}")
                    artifact_type = ArtifactType[artifact_type_str]
                    
                    # 创建文物对象
                    artifact = Artifact(
                        int(artifact_id),  # 确保 ID 是整数
                        name,
                        era,
                        significance,
                        artifact_type
                    )
                    self.artifacts.append(artifact)
                    print(f"行 {idx+1}: 成功加载文物 {artifact.name}")
                    
                except KeyError as e:
                    print(f"行 {idx+1} 缺少字段: {e}")
                except ValueError as e:
                    print(f"行 {idx+1} 数据格式错误: {e}")
                except Exception as e:
                    print(f"行 {idx+1} 加载失败: {e}")
            
            print(f"成功加载 {len(self.artifacts)} 件文物")
            
        except pd.errors.EmptyDataError:
            print(f"错误: CSV 文件为空 - {filepath}")
        except pd.errors.ParserError:
            print(f"错误: CSV 文件格式错误 - {filepath}")
        except Exception as e:
            print(f"未知错误: {e}")

    def load_visitors(self, filename="cultural_heritage_visitors.csv"):
        """从 file 目录加载访客数据，适配实际 CSV 列名"""
        filepath = self.get_file_path(filename)
        print(f"尝试加载访客文件: {filepath}")
        
        if not os.path.exists(filepath):
            print(f"错误: 文件不存在 - {filepath}")
            return
            
        try:
            data = pd.read_csv(filepath)
            print(f"成功读取 CSV 文件，共 {len(data)} 行数据")
            print(f"CSV 列名: {list(data.columns)}")  # 打印实际列名，用于调试
            self.visitor_queue.clear()
            
            # 列名映射字典（代码期望列名 -> 实际 CSV 可能的列名）
            column_mapping = {
                'group_id': ['group_id', 'group_ID'],  # 适配大小写差异
                'arrival_time': ['arrival_time'],
                'reservation_priority': ['reservation_priority'],
                'preference': ['preference', '']  # preference 为可选列
            }
            
            # 查找每个必需列在实际 CSV 中的对应列名
            csv_columns = {}
            for code_col, possible_cols in column_mapping.items():
                found = False
                for csv_col in possible_cols:
                    if csv_col in data.columns:
                        csv_columns[code_col] = csv_col
                        found = True
                        break
                if not found and code_col != 'preference':  # preference 是可选的
                    print(f"错误: 未找到列 '{code_col}' 的匹配项，可能的列名: {possible_cols}")
                    return
            
            print(f"列名映射: {csv_columns}")
            
            for idx, row in data.iterrows():
                try:
                    # 使用映射的列名获取数据
                    group_id = row[csv_columns['group_id']]
                    arrival_time = str(row[csv_columns['arrival_time']]).strip()
                    reservation_priority = str(row[csv_columns['reservation_priority']]).strip()
                    
                    # 处理可选字段 preference
                    preference = None
                    if 'preference' in csv_columns:
                        preference_val = row[csv_columns['preference']]
                        preference = str(preference_val).strip() if pd.notna(preference_val) else None
                    
                    # 创建访客对象
                    visitor = VisitorGroup(
                        int(group_id),  # 确保 ID 是整数
                        arrival_time,
                        reservation_priority,
                        preference
                    )
                    self.visitor_queue.append(visitor)
                    print(f"行 {idx+1}: 成功加载访客组 {group_id}")
                    
                except KeyError as e:
                    print(f"行 {idx+1} 缺少字段: {e}")
                except Exception as e:
                    print(f"行 {idx+1} 加载失败: {e}")
            
            print(f"成功加载 {len(self.visitor_queue)} 个访客组")
            
        except pd.errors.EmptyDataError:
            print(f"错误: CSV 文件为空 - {filepath}")
        except pd.errors.ParserError:
            print(f"错误: CSV 文件格式错误 - {filepath}")
        except Exception as e:
            print(f"未知错误: {e}")

    def add_artifact(self, artifact):
        """添加文物并排序"""
        self.artifacts.append(artifact)
        self.artifacts.sort(key=lambda x: (x.era, x.significance.value, x.artifact_type.value))

    def add_visitor_group(self, visitor_group):
        """添加访客组并排序"""
        self.visitor_queue.append(visitor_group)
        self.visitor_queue.sort(key=lambda x: (x.arrival_time, x.reservation_priority.value))

    def search_artifacts_by_era(self, era):
        """按年代搜索文物"""
        return [a for a in self.artifacts if a.era == era]

    def remove_artifact(self, artifact_id):
        """按 ID 删除文物"""
        self.artifacts = [a for a in self.artifacts if a.artifact_id != artifact_id]

    def remove_visitor_group(self, group_id):
        """按 ID 删除访客组"""
        self.visitor_queue = [v for v in self.visitor_queue if v.group_id != group_id]

    def save_to_csv(self, output_dir="output"):
        """保存数据到 CSV"""
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        artifacts_data = [{
            'artifact_id': a.artifact_id,
            'name': a.name,
            'era': a.era,
            'significance': a.significance.name,
            'artifact_type': a.artifact_type.name
        } for a in self.artifacts]

        visitors_data = [{
            'group_id': v.group_id,
            'arrival_time': v.arrival_time.strftime('%Y-%m-%d %H:%M:%S') if isinstance(v.arrival_time, datetime) else v.arrival_time,
            'reservation_priority': v.reservation_priority.name,
            'preference': v.preference if v.preference else ''
        } for v in self.visitor_queue]

        pd.DataFrame(artifacts_data).to_csv(os.path.join(output_dir, "artifacts.csv"), index=False)
        pd.DataFrame(visitors_data).to_csv(os.path.join(output_dir, "visitors.csv"), index=False)
        print(f"数据已保存到 {output_dir} 目录")