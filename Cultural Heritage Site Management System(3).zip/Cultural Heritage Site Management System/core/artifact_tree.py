import os
import csv
import sys
from pathlib import Path

# 添加项目根目录到Python路径
sys.path.append(str(Path(__file__).parent.parent))

# 修改为绝对导入
from core.artifact import Artifact, Significance, ArtifactType

class ArtifactTreeNode:
    def __init__(self, name):
        self.name = name
        self.children = dict()
        self.is_leaf = False  # 叶节点存文物列表

    def add_child(self, key, node):
        self.children[key] = node

    def get_child(self, key):
        return self.children.get(key)

class ArtifactTree:
    def __init__(self):
        self.root = ArtifactTreeNode("root")

    def add_artifact(self, artifact: Artifact):
        era_node = self.root.get_child(artifact.era)
        if era_node is None:
            era_node = ArtifactTreeNode(artifact.era)
            self.root.add_child(artifact.era, era_node)

        type_node = era_node.get_child(artifact.artifact_type.name)
        if type_node is None:
            type_node = ArtifactTreeNode(artifact.artifact_type.name)
            era_node.add_child(artifact.artifact_type.name, type_node)

        significance_node = type_node.get_child(artifact.significance.name)
        if significance_node is None:
            significance_node = ArtifactTreeNode(artifact.significance.name)
            significance_node.is_leaf = True
            significance_node.children = []
            type_node.add_child(artifact.significance.name, significance_node)

        significance_node.children.append(artifact)

    def display(self, node=None, level=0):
        if node is None:
            node = self.root
        indent = " " * (level * 4)
        if node.name != "root":
            print(f"{indent}{node.name}")
        if node.is_leaf:
            for art in node.children:
                print(f"{indent}    {art}")
        else:
            for child in sorted(node.children.values(), key=lambda x: x.name):
                self.display(child, level + 1)

    def search_artifacts(self, era=None, artifact_type=None, significance=None):
        results = []
        def dfs(node):
            if node.is_leaf:
                for art in node.children:
                    if (era is None or art.era == era) and \
                       (artifact_type is None or art.artifact_type == artifact_type) and \
                       (significance is None or art.significance == significance):
                        results.append(art)
            else:
                for child in node.children.values():
                    dfs(child)
        dfs(self.root)
        return results

def get_file_path(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))       # artifact_tree.py 所在目录
    project_root = os.path.normpath(os.path.join(base_dir, ".."))  # 项目根目录
    return os.path.join(project_root, "file", filename)

def load_artifacts_from_csv(file_path):
    artifacts = []
    if not os.path.exists(file_path):
        print(f"文件不存在: {file_path}")
        return artifacts

    with open(file_path, mode='r', encoding='utf-8') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0].lower() == "artifact_id":  # 跳过表头
                continue
            if len(row) != 5:
                print(f"跳过格式错误行: {row}")
                continue
            try:
                artifact = Artifact(
                    int(row[0]),
                    row[1],
                    row[2],
                    row[3].upper(),
                    row[4].upper()
                )
                artifacts.append(artifact)
            except Exception as e:
                print(f"跳过无效行: {row}, 错误：{e}")
    return artifacts

def export_artifacts_to_csv(artifacts, file_path):
    # 确保输出目录存在
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    
    with open(file_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["artifact_id", "name", "era", "significance", "artifact_type"])
        for art in artifacts:
            writer.writerow([
                art.artifact_id,
                art.name,
                art.era,
                art.significance.name,
                art.artifact_type.name
            ])

if __name__ == "__main__":
    # 自动计算路径
    csv_input_path = get_file_path("cultural_heritage_artifacts.csv")
    csv_output_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output", "filtered_artifacts.csv")

    print(f"读取路径: {csv_input_path}")
    print(f"输出路径: {csv_output_path}")

    tree = ArtifactTree()
    artifacts = load_artifacts_from_csv(csv_input_path)
    for art in artifacts:
        tree.add_artifact(art)

    print("\n文物树结构展示：")
    tree.display()

    print("\n筛选 Ancient + HIGH + SCULPTURE 文物：")
    filtered = tree.search_artifacts(
        era="Ancient",
        artifact_type=ArtifactType.SCULPTURE,
        significance=Significance.HIGH
    )
    for art in filtered:
        print(art)

    print(f"\n导出 {len(filtered)} 件筛选文物到 CSV：{csv_output_path}")
    export_artifacts_to_csv(filtered, csv_output_path)