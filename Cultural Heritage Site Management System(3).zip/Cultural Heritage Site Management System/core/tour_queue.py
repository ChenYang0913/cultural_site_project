from dataclasses import dataclass
from enum import Enum
from typing import Optional, List
import csv
from datetime import datetime
import os  # 新增，用于路径处理

# 游客组重要性枚举
class Significance(Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

# 游客组数据类
@dataclass
class Group:
    group_id: str
    arrival_time: datetime
    reservation_priority: Significance

    def __repr__(self) -> str:
        return (f"Group(group_id={self.group_id}, "
                f"arrival_time={self.arrival_time.strftime('%Y-%m-%d %H:%M:%S')}, "
                f"reservation_priority={self.reservation_priority.name})")

    def __eq__(self, other) -> bool:
        if not isinstance(other, Group):
            return False
        return self.group_id == other.group_id

# 双向链表节点类
class Node:
    def __init__(self, value: Group, prev: Optional['Node'] = None, next: Optional['Node'] = None):
        self.value = value
        self.prev = prev
        self.next = next

# 导览队列类（双向链表实现）
class TourQueue:
    def __init__(self):
        self.head: Optional[Node] = None
        self.tail: Optional[Node] = None
        self.size = 0

    def is_empty(self) -> bool:
        return self.size == 0

    def add_group(self, group: Group) -> None:
        """按优先级+到达时间排序插入游客组"""
        new_node = Node(group)
        self.size += 1

        # 处理空队列情况
        if self.is_empty():
            self.head = self.tail = new_node
            return

        # 寻找插入位置（优先级高或时间早的在前）
        current = self.head
        insert_before = False
        
        while current is not None:
            # 关键修复：使用 < 比较优先级值，因为值越小优先级越高
            if (group.reservation_priority.value < current.value.reservation_priority.value) or \
               (group.reservation_priority == current.value.reservation_priority and 
                group.arrival_time < current.value.arrival_time):
                insert_before = True
                break
            current = current.next

        # 根据插入位置调整指针
        if insert_before:
            # 插入到 current 节点之前
            if current.prev is None:
                # 插入到队首
                new_node.next = self.head
                if self.head:  # 确保 head 不为 None
                    self.head.prev = new_node
                self.head = new_node
            else:
                # 插入到中间
                new_node.prev = current.prev
                new_node.next = current
                if current.prev:  # 确保前一个节点存在
                    current.prev.next = new_node
                current.prev = new_node
        else:
            # 插入到队尾
            new_node.prev = self.tail
            if self.tail:  # 确保 tail 不为 None
                self.tail.next = new_node
            self.tail = new_node

            # 额外检查：如果队尾插入后 head 为 None（不可能的情况，但保险起见）
            if self.head is None:
                self.head = new_node

    def remove_group(self, group: Group) -> bool:
        """移除指定游客组"""
        current = self.head
        while current is not None:
            if current.value == group:
                # 更新前一个节点的 next 指针
                if current.prev:
                    current.prev.next = current.next
                else:
                    # 如果删除的是头节点，更新头节点
                    self.head = current.next
                    if self.head is not None:
                        self.head.prev = None  # 新头节点的 prev 应为 None
                    else:
                        self.tail = None  # 队列为空时，尾节点也为 None

                # 更新后一个节点的 prev 指针
                if current.next:
                    current.next.prev = current.prev
                else:
                    # 如果删除的是尾节点，更新尾节点
                    self.tail = current.prev
                    if self.tail is not None:
                        self.tail.next = None  # 新尾节点的 next 应为 None
                    else:
                        self.head = None  # 队列为空时，头节点也为 None

                self.size -= 1
                return True
            current = current.next
        return False

    def peek_next_group(self) -> Optional[Group]:
        """查看下一个游客组（不移除）"""
        return self.head.value if self.head else None

    def reschedule_group(self, group_id: str, new_arrival_time: datetime) -> bool:
        """重新安排游客组的到达时间并重新排序"""
        target = self._find_group_by_id(group_id)
        if not target:
            return False
        
        # 创建新的游客组实例（保持相同的优先级）
        new_group = Group(
            group_id=group_id,
            arrival_time=new_arrival_time,
            reservation_priority=target.reservation_priority
        )
        
        # 先移除原组，再添加新组
        self.remove_group(target)
        self.add_group(new_group)
        return True

    def _find_group_by_id(self, group_id: str) -> Optional[Group]:
        """内部方法：按 ID 查找游客组"""
        current = self.head
        while current is not None:
            if current.value.group_id == group_id:
                return current.value
            current = current.next
        return None

    def to_list(self) -> List[Group]:
        """转换为列表（用于测试和查看）"""
        result = []
        current = self.head
        while current is not None:
            result.append(current.value)
            current = current.next
        return result

# 从 CSV 文件加载数据
def load_from_csv(file_name: str = "cultural_heritage_visitors.csv") -> TourQueue:  # 改为默认文件名参数，更灵活
    """从 CSV 文件加载游客组数据并初始化队列，默认从 file 文件夹读取"""
    # 获取当前文件（tour_queue.py）的绝对路径
    current_file_path = os.path.abspath(__file__)
    # 获取当前文件所在目录（artifact_management 文件夹）
    current_dir = os.path.dirname(current_file_path)
    # 获取项目根目录（Cultural-main 文件夹）
    project_root = os.path.dirname(current_dir)
    # 拼接出 CSV 文件的相对路径（假设 CSV 放在 file 文件夹下）
    csv_path = os.path.join(project_root, "file", file_name)
    
    queue = TourQueue()
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    group = Group(
                        group_id=row['group_id'],
                        arrival_time=datetime.strptime(row['arrival_time'], '%Y-%m-%d %H:%M:%S'),
                        reservation_priority=Significance[row['reservation_priority'].upper()]
                    )
                    queue.add_group(group)
                except (ValueError, KeyError) as e:
                    print(f"无效数据行，跳过：{row}，错误：{e}")
    except FileNotFoundError:
        print(f"错误：找不到 CSV 文件 {csv_path}")
    return queue