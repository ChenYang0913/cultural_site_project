import os

def get_project_root():
    """获取项目根目录(即包含core、file等文件夹的目录)"""
    # 当前文件是path_utils.py，其父目录是core，再上一级就是项目根目录
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def get_file_path(relative_path):
    """根据相对路径获取绝对路径"""
    return os.path.join(get_project_root(), relative_path)