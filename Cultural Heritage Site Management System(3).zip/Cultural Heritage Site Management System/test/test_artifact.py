# test/test_artifact.py
import sys
import os
import unittest
from core.artifact import Artifact, ArtifactType, Significance
from core.artifact_tree import ArtifactTree

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.append(project_root)

class TestArtifactTree(unittest.TestCase):
    def setUp(self):
        self.tree = ArtifactTree()

    def test_add_artifact(self):
        artifact1 = Artifact(1, "Artifact1", "Era1", Significance.HIGH, ArtifactType.SCULPTURE)
        self.tree.add_artifact(artifact1)
        
        # 验证 era 节点存在
        era_node = self.tree.root.get_child("Era1")
        self.assertIsNotNone(era_node)
        
        # 验证 type 节点存在
        type_node = era_node.get_child(ArtifactType.SCULPTURE.name)
        self.assertIsNotNone(type_node)
        
        # 验证 significance 节点存在且包含文物
        significance_node = type_node.get_child(Significance.HIGH.name)
        self.assertIsNotNone(significance_node)
        self.assertEqual(len(significance_node.children), 1)
        self.assertEqual(significance_node.children[0].artifact_id, 1)

    def test_search_artifacts_by_era(self):
        artifact1 = Artifact(1, "Artifact1", "Era1", Significance.HIGH, ArtifactType.SCULPTURE)
        artifact2 = Artifact(2, "Artifact2", "Era2", Significance.MEDIUM, ArtifactType.PAINTING)
        self.tree.add_artifact(artifact1)
        self.tree.add_artifact(artifact2)
        
        # 使用实际存在的 search_artifacts 方法
        found = self.tree.search_artifacts(era="Era1")
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].artifact_id, 1)

    def test_search_artifacts_by_type_and_significance(self):
        artifact1 = Artifact(1, "Artifact1", "Era1", Significance.HIGH, ArtifactType.SCULPTURE)
        artifact2 = Artifact(2, "Artifact2", "Era2", Significance.MEDIUM, ArtifactType.PAINTING)
        self.tree.add_artifact(artifact1)
        self.tree.add_artifact(artifact2)
        
        # 使用实际存在的 search_artifacts 方法
        found = self.tree.search_artifacts(
            artifact_type=ArtifactType.PAINTING,
            significance=Significance.MEDIUM
        )
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].artifact_id, 2)

if __name__ == "__main__":
    unittest.main()