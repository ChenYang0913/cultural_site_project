import unittest
from datetime import datetime
from core.tour_queue import TourQueue, Group, Significance, load_from_csv

class TestTourQueue(unittest.TestCase):
    def setUp(self):
        """初始化测试数据"""
        self.queue = TourQueue()
        self.group1 = Group("G001", datetime(2024, 7, 4, 10, 0), Significance.HIGH)
        self.group2 = Group("G002", datetime(2024, 7, 4, 9, 30), Significance.MEDIUM)
        self.group3 = Group("G003", datetime(2024, 7, 4, 10, 30), Significance.HIGH)

    def test_add_group(self):
        """测试添加游客组并验证排序"""
        self.queue.add_group(self.group1)
        self.queue.add_group(self.group2)
        self.queue.add_group(self.group3)
        
        # 验证队列顺序：高优先级优先，同优先级按到达时间排序
        self.assertEqual(
            self.queue.to_list(), 
            [self.group1, self.group3, self.group2]
        )

    def test_remove_group(self):
        """测试移除游客组"""
        self.queue.add_group(self.group1)
        self.queue.add_group(self.group2)
        
        # 移除存在的组
        self.assertTrue(self.queue.remove_group(self.group1))
        self.assertEqual(self.queue.to_list(), [self.group2])
        
        # 移除不存在的组
        self.assertFalse(self.queue.remove_group(self.group3))

    def test_peek_next_group(self):
        """测试查看下一个游客组"""
        self.queue.add_group(self.group2)  # MEDIUM 9:30
        self.queue.add_group(self.group1)  # HIGH 10:00
        
        # 优先级高的 group1 应该在队首
        self.assertEqual(self.queue.peek_next_group(), self.group1)

    def test_reschedule_group(self):
        """测试重新安排游客组时间"""
        self.queue.add_group(self.group1)  # G001 10:00 HIGH
        self.queue.add_group(self.group3)  # G003 10:30 HIGH
        
        # 调整 G001 的时间为更早
        new_time = datetime(2024, 7, 4, 9, 0)
        self.assertTrue(self.queue.reschedule_group("G001", new_time))
        
        # 新队列顺序：G001（9:00 HIGH）→ G003（10:30 HIGH）
        self.assertEqual(
            self.queue.to_list(), 
            [Group("G001", new_time, Significance.HIGH), self.group3]
        )

    def test_load_from_csv(self):
        """测试从 CSV 文件加载数据"""
        # 注意：需要在测试目录下创建一个示例 CSV 文件
        # 或使用临时文件（此处简化处理）
        try:
            queue = load_from_csv("test_data.csv")
            self.assertIsInstance(queue, TourQueue)
            # 可进一步验证 CSV 加载的数据（根据实际文件内容）
        except FileNotFoundError:
            # 测试环境可能没有该文件，跳过此测试
            self.skipTest("测试 CSV 文件不存在，跳过此测试")

if __name__ == '__main__':
    unittest.main()