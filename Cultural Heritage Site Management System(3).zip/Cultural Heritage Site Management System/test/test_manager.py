import sys
import os
import unittest

# 添加项目根目录到sys.path
current_file = os.path.abspath(__file__)
test_dir = os.path.dirname(current_file)
project_root = os.path.dirname(test_dir)
sys.path.insert(0, project_root)

from core.manager import CulturalHeritageSiteManager
from core.artifact import Artifact, ArtifactType, Significance

class TestManager(unittest.TestCase):
    def setUp(self):
        self.manager = CulturalHeritageSiteManager()
        
    def test_add_artifact(self):
        artifact = Artifact(1, "Test Artifact", "Ancient", Significance.HIGH, ArtifactType.SCULPTURE)
        self.manager.add_artifact(artifact)
        self.assertEqual(len(self.manager.artifacts), 1)
        self.assertIn(artifact, self.manager.artifacts)
        
    def test_remove_artifact(self):
        artifact = Artifact(1, "Test Artifact", "Ancient", Significance.HIGH, ArtifactType.SCULPTURE)
        self.manager.add_artifact(artifact)
        self.manager.remove_artifact(1)
        self.assertEqual(len(self.manager.artifacts), 0)
        
    # 其他测试方法...

if __name__ == '__main__':
    unittest.main()