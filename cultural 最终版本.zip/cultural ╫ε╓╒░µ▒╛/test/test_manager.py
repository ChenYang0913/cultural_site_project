# import sys
# import os
# import unittest

# # 添加项目根目录到sys.path
# current_file = os.path.abspath(__file__)
# test_dir = os.path.dirname(current_file)
# project_root = os.path.dirname(test_dir)
# sys.path.insert(0, project_root)

# from core.manager import CulturalHeritageSiteManager
# from core.models.artifact import Artifact, ArtifactType, Significance

# class TestManager(unittest.TestCase):
#     def setUp(self):
#         self.manager = CulturalHeritageSiteManager()
        
#     def test_add_artifact(self):
#         artifact = Artifact(1, "Test Artifact", "Ancient", Significance.HIGH, ArtifactType.SCULPTURE)
#         self.manager.add_artifact(artifact)
#         self.assertEqual(len(self.manager.artifacts), 1)
#         self.assertIn(artifact, self.manager.artifacts)
        
#     def test_remove_artifact(self):
#         artifact = Artifact(1, "Test Artifact", "Ancient", Significance.HIGH, ArtifactType.SCULPTURE)
#         self.manager.add_artifact(artifact)
#         self.manager.remove_artifact(1)
#         self.assertEqual(len(self.manager.artifacts), 0)
        
#     # 其他测试方法...

# if __name__ == '__main__':
#     unittest.main()


# import sys
# import os
# import unittest

# # 添加项目根目录到sys.path
# current_file = os.path.abspath(__file__)
# test_dir = os.path.dirname(current_file)
# project_root = os.path.dirname(test_dir)
# sys.path.insert(0, project_root)

# from core.manager import CulturalHeritageSiteManager
# from core.models.artifact import Artifact, ArtifactType, Significance

# class TestManager(unittest.TestCase):
#     def setUp(self):
#         self.manager = CulturalHeritageSiteManager()
        
#     def test_add_artifact(self):
#         artifact = Artifact(1, "Test Artifact", "Ancient", Significance.HIGH, ArtifactType.SCULPTURE)
#         self.manager.add_artifact(artifact)
#         self.assertEqual(len(self.manager.artifacts), 1)
#         self.assertIn(artifact, self.manager.artifacts)
        
#     def test_remove_artifact(self):
#         artifact = Artifact(1, "Test Artifact", "Ancient", Significance.HIGH, ArtifactType.SCULPTURE)
#         self.manager.add_artifact(artifact)
#         self.manager.remove_artifact(1)
#         self.assertEqual(len(self.manager.artifacts), 0)
        
#     # 其他测试方法...

# if __name__ == '__main__':
#     unittest.main()


import sys
import os
import unittest
import tempfile
import csv
from core.manager import CulturalHeritageManager
from core.models.artifact import Artifact, Significance, ArtifactType
from core.models.visitors import VisitorGroup, ReservationPriority

# 添加项目根目录到sys.path
current_file = os.path.abspath(__file__)
test_dir = os.path.dirname(current_file)
project_root = os.path.dirname(test_dir)
sys.path.insert(0, project_root)

class TestCulturalHeritageManager(unittest.TestCase):
    """文化遗产管理器的单元测试"""
    
    def setUp(self):
        """测试前的准备工作"""
        self.manager = CulturalHeritageManager()
        
        # 创建测试文物
        self.artifact1 = Artifact(
            artifact_id=1,
            name="Test Artifact 1",
            era="Ancient",
            significance=Significance.HIGH,
            artifact_type=ArtifactType.SCULPTURE
        )
        
        self.artifact2 = Artifact(
            artifact_id=2,
            name="Test Artifact 2",
            era="Renaissance",
            significance=Significance.MEDIUM,
            artifact_type=ArtifactType.PAINTING
        )
        
        # 创建测试游客组
        self.visitor1 = VisitorGroup(
            group_id=1,
            count=10,
            arrival_time="09:00",
            reservation_priority=ReservationPriority.HIGH
        )
        
        self.visitor2 = VisitorGroup(
            group_id=2,
            count=8,
            arrival_time="10:30",
            reservation_priority=ReservationPriority.MEDIUM,
            preferred_era="Ancient"
        )
    
    def test_manager_initialization(self):
        """测试管理器初始化"""
        self.assertIsNotNone(self.manager.artifact_tree)
        self.assertIsNotNone(self.manager.tour_queue)
        self.assertEqual(len(self.manager.artifact_tree), 0)
        self.assertEqual(len(self.manager.tour_queue), 0)
    
    def test_add_artifact(self):
        """测试添加文物"""
        result = self.manager.add_artifact(self.artifact1)
        self.assertTrue(result)
        self.assertEqual(len(self.manager.artifact_tree), 1)
        
        # 验证文物在树中
        found = self.manager.find_artifact(1)
        self.assertEqual(found, self.artifact1)
    
    def test_remove_artifact(self):
        """测试移除文物"""
        self.manager.add_artifact(self.artifact1)
        self.assertEqual(len(self.manager.artifact_tree), 1)
        
        removed = self.manager.remove_artifact(1)
        self.assertEqual(removed, self.artifact1)
        self.assertEqual(len(self.manager.artifact_tree), 0)
        
        # 验证文物已从树中移除
        found = self.manager.find_artifact(1)
        self.assertIsNone(found)
    
    def test_find_artifact(self):
        """测试查找文物"""
        self.manager.add_artifact(self.artifact1)
        
        found = self.manager.find_artifact(1)
        self.assertEqual(found, self.artifact1)
        
        not_found = self.manager.find_artifact(999)
        self.assertIsNone(not_found)
    
    def test_search_artifacts(self):
        """测试搜索文物"""
        self.manager.add_artifact(self.artifact1)  # SCULPTURE, HIGH
        self.manager.add_artifact(self.artifact2)  # PAINTING, MEDIUM
        
        # 按类型搜索
        sculptures = self.manager.search_artifacts(artifact_type=ArtifactType.SCULPTURE)
        self.assertEqual(len(sculptures), 1)
        self.assertEqual(sculptures[0], self.artifact1)
        
        # 按重要性搜索
        high_artifacts = self.manager.search_artifacts(significance=Significance.HIGH)
        self.assertEqual(len(high_artifacts), 1)
        self.assertEqual(high_artifacts[0], self.artifact1)
        
        # 组合搜索
        high_paintings = self.manager.search_artifacts(
            artifact_type=ArtifactType.PAINTING,
            significance=Significance.HIGH
        )
        self.assertEqual(len(high_paintings), 0)  # 没有高重要性的绘画
    
    def test_get_artifacts_by_era(self):
        """测试按时代获取文物"""
        self.manager.add_artifact(self.artifact1)  # Ancient
        self.manager.add_artifact(self.artifact2)  # Renaissance
        
        ancient_artifacts = self.manager.get_artifacts_by_era("Ancient")
        self.assertEqual(len(ancient_artifacts), 1)
        self.assertEqual(ancient_artifacts[0], self.artifact1)
        
        renaissance_artifacts = self.manager.get_artifacts_by_era("Renaissance")
        self.assertEqual(len(renaissance_artifacts), 1)
        self.assertEqual(renaissance_artifacts[0], self.artifact2)
    
    def test_add_visitor_group(self):
        """测试添加游客组"""
        result = self.manager.add_visitor_group(self.visitor1)
        self.assertTrue(result)
        self.assertEqual(len(self.manager.tour_queue), 1)
        
        # 验证游客组在队列中
        found = self.manager.tour_queue.get_visitor_group(1)
        self.assertEqual(found, self.visitor1)
    
    def test_remove_visitor_group(self):
        """测试移除游客组"""
        self.manager.add_visitor_group(self.visitor1)
        self.assertEqual(len(self.manager.tour_queue), 1)
        
        removed = self.manager.remove_visitor_group(1)
        self.assertEqual(removed, self.visitor1)
        self.assertEqual(len(self.manager.tour_queue), 0)
        
        # 验证游客组已从队列中移除
        found = self.manager.tour_queue.get_visitor_group(1)
        self.assertIsNone(found)
    
    def test_get_next_visitor_group(self):
        """测试获取下一个游客组"""
        # 空队列
        next_group = self.manager.get_next_visitor_group()
        self.assertIsNone(next_group)
        
        # 添加游客组
        self.manager.add_visitor_group(self.visitor1)
        next_group = self.manager.get_next_visitor_group()
        self.assertEqual(next_group, self.visitor1)
        self.assertEqual(len(self.manager.tour_queue), 1)  # 数量不变
    
    def test_dequeue_next_visitor_group(self):
        """测试移除并返回下一个游客组"""
        # 空队列
        next_group = self.manager.dequeue_next_visitor_group()
        self.assertIsNone(next_group)
        
        # 添加游客组
        self.manager.add_visitor_group(self.visitor1)
        next_group = self.manager.dequeue_next_visitor_group()
        self.assertEqual(next_group, self.visitor1)
        self.assertEqual(len(self.manager.tour_queue), 0)
    
    def test_reschedule_visitor_group(self):
        """测试重新安排游客组时间"""
        self.manager.add_visitor_group(self.visitor1)
        
        result = self.manager.reschedule_visitor_group(1, "15:00")
        self.assertTrue(result)
        
        # 验证时间已更新
        updated_group = self.manager.tour_queue.get_visitor_group(1)
        self.assertEqual(updated_group.arrival_time, "15:00")
        self.assertEqual(updated_group.reservation_priority, ReservationPriority.HIGH)  # 优先级不变
    
    def test_get_artifacts_for_visitor_preference(self):
        """测试根据游客偏好获取文物"""
        self.manager.add_artifact(self.artifact1)  # Ancient
        self.manager.add_artifact(self.artifact2)  # Renaissance
        
        ancient_artifacts = self.manager.get_artifacts_for_visitor_preference("Ancient")
        self.assertEqual(len(ancient_artifacts), 1)
        self.assertEqual(ancient_artifacts[0], self.artifact1)
        
        renaissance_artifacts = self.manager.get_artifacts_for_visitor_preference("Renaissance")
        self.assertEqual(len(renaissance_artifacts), 1)
        self.assertEqual(renaissance_artifacts[0], self.artifact2)
    
    def test_optimize_tour_for_visitor_group(self):
        """测试为游客组优化导览路线"""
        self.manager.add_artifact(self.artifact1)  # Ancient
        self.manager.add_visitor_group(self.visitor2)  # 偏好Ancient
        
        optimized_artifacts = self.manager.optimize_tour_for_visitor_group(2)
        self.assertIsNotNone(optimized_artifacts)
        self.assertEqual(len(optimized_artifacts), 1)
        self.assertEqual(optimized_artifacts[0], self.artifact1)
        
        # 测试没有偏好的游客组
        optimized_artifacts = self.manager.optimize_tour_for_visitor_group(1)
        self.assertIsNone(optimized_artifacts)
    
    def test_get_system_statistics(self):
        """测试获取系统统计信息"""
        self.manager.add_artifact(self.artifact1)
        self.manager.add_visitor_group(self.visitor1)
        
        stats = self.manager.get_system_statistics()
        
        self.assertIn('artifacts', stats)
        self.assertIn('visitors', stats)
        self.assertIn('data_loaded', stats)
        
        self.assertEqual(stats['artifacts']['total_artifacts'], 1)
        self.assertEqual(stats['visitors']['total_groups'], 1)
    
    def test_clear_all_data(self):
        """测试清空所有数据"""
        self.manager.add_artifact(self.artifact1)
        self.manager.add_visitor_group(self.visitor1)
        
        self.assertEqual(len(self.manager.artifact_tree), 1)
        self.assertEqual(len(self.manager.tour_queue), 1)
        
        self.manager.clear_all_data()
        
        self.assertEqual(len(self.manager.artifact_tree), 0)
        self.assertEqual(len(self.manager.tour_queue), 0)
    
    def test_load_artifacts_from_csv(self):
        """测试从CSV加载文物数据"""
        # 创建临时CSV文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            writer = csv.writer(f)
            writer.writerow(['ID', '名称', '年代', '重要性', '类型'])
            writer.writerow([1, 'Test Artifact', 'Ancient', 'HIGH', 'SCULPTURE'])
            temp_file = f.name
        
        try:
            result = self.manager.load_artifacts_from_csv(temp_file)
            self.assertTrue(result)
            self.assertEqual(len(self.manager.artifact_tree), 1)
            
            # 验证加载的文物
            found = self.manager.find_artifact(1)
            self.assertIsNotNone(found)
            self.assertEqual(found.name, 'Test Artifact')
            self.assertEqual(found.era, 'Ancient')
            self.assertEqual(found.significance, Significance.HIGH)
            self.assertEqual(found.artifact_type, ArtifactType.SCULPTURE)
        finally:
            os.unlink(temp_file)
    
    def test_load_visitors_from_csv(self):
        """测试从CSV加载游客数据"""
        # 创建临时CSV文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            writer = csv.writer(f)
            writer.writerow(['group_ID', 'arrival_time', 'reservation_priority'])
            writer.writerow([1, '09:00', 'HIGH'])
            temp_file = f.name
        
        try:
            result = self.manager.load_visitors_from_csv(temp_file)
            self.assertTrue(result)
            self.assertEqual(len(self.manager.tour_queue), 1)
            
            # 验证加载的游客组
            found = self.manager.tour_queue.get_visitor_group(1)
            self.assertIsNotNone(found)
            self.assertEqual(found.arrival_time, '09:00')
            self.assertEqual(found.reservation_priority, ReservationPriority.HIGH)
        finally:
            os.unlink(temp_file)
    
    def test_export_filtered_artifacts(self):
        """测试导出过滤后的文物数据"""
        self.manager.add_artifact(self.artifact1)  # SCULPTURE, HIGH
        self.manager.add_artifact(self.artifact2)  # PAINTING, MEDIUM
        
        # 创建临时输出文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            temp_file = f.name
        
        try:
            # 导出高重要性的文物
            result = self.manager.export_filtered_artifacts(
                temp_file, significance=Significance.HIGH
            )
            self.assertTrue(result)
            
            # 验证导出的文件
            with open(temp_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                rows = list(reader)
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]['ID'], '1')
                self.assertEqual(rows[0]['名称'], 'Test Artifact 1')
                self.assertEqual(rows[0]['重要性'], 'HIGH')
        finally:
            os.unlink(temp_file)
    
    def test_get_tree_structure(self):
        """测试获取树结构"""
        self.manager.add_artifact(self.artifact1)
        
        structure = self.manager.get_tree_structure()
        self.assertEqual(structure['key'], 'root')
        self.assertIn('Ancient', structure['children'])
        
        ancient_node = structure['children']['Ancient']
        self.assertEqual(ancient_node['key'], 'Ancient')
        self.assertIn('SCULPTURE', ancient_node['children'])
    
    def test_get_queue_structure(self):
        """测试获取队列结构"""
        self.manager.add_visitor_group(self.visitor1)
        
        structure = self.manager.get_queue_structure()
        self.assertEqual(structure['total_groups'], 1)
        self.assertEqual(len(structure['groups']), 1)
        self.assertIn('statistics', structure)
    
    def test_manager_repr(self):
        """测试管理器的字符串表示"""
        self.manager.add_artifact(self.artifact1)
        self.manager.add_visitor_group(self.visitor1)
        
        expected = "CulturalHeritageManager(artifacts=1, visitors=1)"
        self.assertEqual(repr(self.manager), expected)


if __name__ == '__main__':
    unittest.main()