from enum import Enum
from typing import Optional


class Significance(Enum):
    """Enumeration of cultural relics importance"""
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class ArtifactType(Enum):
    """Enumeration of artifact types"""
    SCULPTURE = "SCULPTURE"
    PAINTING = "PAINTING"
    DOCUMENT = "DOCUMENT"
    POTTERY = "POTTERY"
    JEWELRY = "JEWELRY"
    WEAPON = "WEAPON"
    TOOL = "TOOL"
    TEXTILE = "TEXTILE"


class Artifact:
    """The cultural relics category represents each cultural relic in the site"""
    
    def __init__(self, artifact_id: int, name: str, era: str, artifact_type: ArtifactType, significance: Significance, description: str = ""):
        """
        Initialize the artifact object
        
        Args:
            artifact_id: 文物编号
            name: 文物名称
            era: 所属时代
            significance: 重要性
            artifact_type: 文物类型
            description: 描述信息
        """
        self.artifact_id = artifact_id
        self.name = name
        self.era = era
        self.artifact_type = artifact_type
        self.significance = significance
        self.description = description
    
    def __repr__(self) -> str:
        """Returns a string representation of the artifact"""
        return (f"Artifact(id={self.artifact_id}, name='{self.name}', "
                f"era='{self.era}', significance={self.significance.value}, "
                f"type={self.artifact_type.value})")
    
    def __eq__(self, other) -> bool:
        """Compare whether two artifacts are equal"""
        if not isinstance(other, Artifact):
            return False
        return self.artifact_id == other.artifact_id
    
    def __lt__(self, other) -> bool:
        """Compare the size of two artifacts (in order of importance)"""
        if not isinstance(other, Artifact):
            return False
        
        # Importance priority：HIGH > MEDIUM > LOW
        significance_order = {Significance.HIGH: 3, Significance.MEDIUM: 2, Significance.LOW: 1}
        
        if self.significance != other.significance:
            return significance_order[self.significance] < significance_order[other.significance]
        
        # If the importance is the same, sort by ID
        return self.artifact_id < other.artifact_id
    
    def __hash__(self) -> int:
        """The hash value of the artifact object"""
        return hash(self.artifact_id)
    
    def to_dict(self) -> dict:
        """Converts artifact objects to dictionary format"""
        return {
            'artifact_id': self.artifact_id,
            'name': self.name,
            'era': self.era,
            'type': self.artifact_type.value,
            'significance': self.significance.value,
            'description': self.description
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Artifact':
        """Create an artifact object from a dictionary"""
        return cls(
            artifact_id=data['artifact_id'],
            name=data['name'],
            era=data['era'],
            artifact_type=ArtifactType(data['type']),
            significance=Significance(data['significance']),
            description=data.get('description', "")
        )