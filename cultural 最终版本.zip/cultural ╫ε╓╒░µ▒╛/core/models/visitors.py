from enum import Enum
from typing import Optional
from datetime import datetime, time


class ReservationPriority(Enum):
    """Appointment priority enumeration"""
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class VisitorGroup:
    """Tourist group class, which represents a group of tourists"""
    
    def __init__(self, group_id: int, count: int, arrival_time: str, 
                 reservation_priority: ReservationPriority, 
                 preferred_era: Optional[str] = None):
        """
        Initialize the guest group object
        
        Args:
            group_id: 游客组编号
            count: 游客人数
            arrival_time: 到达时间（格式：HH:MM）
            reservation_priority: 预约优先级
            preferred_era: 偏好的历史时代
        """
        self.group_id = group_id
        self.count = count
        self.arrival_time = arrival_time
        self.reservation_priority = reservation_priority
        self.preferred_era = preferred_era
    
    def __repr__(self) -> str:
        """Returns a string representation of the guest group"""
        era_info = f", preferred_era='{self.preferred_era}'" if self.preferred_era else ""
        return (f"VisitorGroup(id={self.group_id}, count={self.count}, arrival_time='{self.arrival_time}', "
                f"priority={self.reservation_priority.value}{era_info})")
    
    def __eq__(self, other) -> bool:
        """Compare whether two groups of visitors are equal"""
        if not isinstance(other, VisitorGroup):
            return False
        return self.group_id == other.group_id
    
    def __lt__(self, other) -> bool:
        """Compare the size of two groups of visitors (for priority queue sorting)"""
        if not isinstance(other, VisitorGroup):
            return False
        
        # Order of priority：HIGH > MEDIUM > LOW
        priority_order = {
            ReservationPriority.HIGH: 1,  # The lower the number, the higher the priority
            ReservationPriority.MEDIUM: 2,
            ReservationPriority.LOW: 3
        }
        
        # Start by prioritization
        if self.reservation_priority != other.reservation_priority:
            return priority_order[self.reservation_priority] < priority_order[other.reservation_priority]
        
        # If the priority is the same, sort by arrival time
        return self._parse_time(self.arrival_time) < self._parse_time(other.arrival_time)
    
    def __hash__(self) -> int:
        """The hash value of the visitor group object"""
        return hash(self.group_id)
    
    def _parse_time(self, time_str: str) -> time:
        """The parsed time string is a time object"""
        try:
            return datetime.strptime(time_str, "%H:%M").time()
        except ValueError:
            # If parsing fails, the default time is returned
            return time(0, 0)
    
    def get_priority_score(self) -> int:
        """Get a priority score"""
        priority_scores = {
            ReservationPriority.HIGH: 3,
            ReservationPriority.MEDIUM: 2,
            ReservationPriority.LOW: 1
        }
        return priority_scores[self.reservation_priority]
    
    def to_dict(self) -> dict:
        """Converts the guest group object to dictionary format"""
        return {
            'group_id': self.group_id,
            'count': self.count,
            'arrival_time': self.arrival_time,
            'reservation_priority': self.reservation_priority.value,
            'preferred_era': self.preferred_era
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'VisitorGroup':
        """Create a guest group object from the dictionary"""
        return cls(
            group_id=data['group_id'],
            count=data.get('count', 1),
            arrival_time=data['arrival_time'],
            reservation_priority=ReservationPriority(data['reservation_priority']),
            preferred_era=data.get('preferred_era')
        )